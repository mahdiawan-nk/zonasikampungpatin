@extends('components.layouts.landing')
@section('content')
    <section class="mt-25">
        <div id="legend" class="absolute top-18 left-4 bg-white shadow-lg rounded-sm p-2 z-50 text-sm">
            <h3 class="font-semibold mb-2">Legenda</h3>
            <div id="legend-items"></div>
        </div>
        <div id="map"class="mt-17"></div>
    </section>
@endsection
@push('styles')
    <link href="https://api.mapbox.com/mapbox-gl-js/v3.17.0-beta.1/mapbox-gl.css" rel="stylesheet">
    <style>
        #map {
            position: absolute;
            top: 0;
            bottom: 0;
            width: 100%;
        }
    </style>
@endpush
@push('scripts')
    <script src="https://api.mapbox.com/mapbox-gl-js/v3.17.0-beta.1/mapbox-gl.js"></script>
    <script>
        // util: ubah array rgba -> string css
        function rgbaArrayToCss(arr) {
            // contoh: ['rgba', 255, 0, 0, 0.5] atau ['rgb',255,0,0]
            if (!Array.isArray(arr) || arr.length < 2) return null;
            const t = arr[0];
            if (t === 'rgba' || t === 'rgb') {
                const nums = arr.slice(1).map(n => Number(n));
                if (t === 'rgba') return `rgba(${nums[0]}, ${nums[1]}, ${nums[2]}, ${nums[3]})`;
                return `rgb(${nums[0]}, ${nums[1]}, ${nums[2]})`;
            }
            return null;
        }

        // util: ambil warna dari paint/expr sederhana
        function evaluateColorValue(val) {
            if (!val) return null;

            // string literal: "#ff00aa" atau "rgba(...)" atau "transparent"
            if (typeof val === 'string') return val;

            // array expression: coba beberapa pola
            if (Array.isArray(val)) {
                // rgba / rgb array
                const rgba = rgbaArrayToCss(val);
                if (rgba) return rgba;

                // match expression: ['match', ['get', 'prop'], 'value1', '#f00', 'value2', '#0f0', '#fff']
                if (val[0] === 'match') {
                    // ambil default (akhir) jika ada
                    const last = val[val.length - 1];
                    if (typeof last === 'string') return last;
                }

                // case expression: ['case', cond1, color1, cond2, color2, default]
                if (val[0] === 'case') {
                    const last = val[val.length - 1];
                    if (typeof last === 'string') return last;
                }

                // step/interval/expression lain -> fallback null
                return null;
            }

            return null;
        }

        // UTAMA: dapatkan warna layer
        function getLayerColor(map, layerId) {
            const styleLayer = map.getStyle().layers.find(l => l.id === layerId);
            if (!styleLayer || !styleLayer.paint) return null;

            // kandidat properti
            const keys = [
                'fill-color',
                'line-color',
                'circle-color',
                'background-color',
                'fill-outline-color'
            ];

            let val = null;
            for (const key of keys) {
                if (styleLayer.paint[key] !== undefined) {
                    val = styleLayer.paint[key];
                    break;
                }
            }
            if (!val) return null;

            // 1. Literal warna string
            if (typeof val === "string") return val;

            // 2. rgba/rgb array
            if (Array.isArray(val) && (val[0] === "rgba" || val[0] === "rgb")) {
                return rgbaArrayToCss(val);
            }

            // 3. match expression => ambil default
            if (Array.isArray(val) && val[0] === "match") {
                const last = val[val.length - 1];
                return typeof last === "string" ? last : null;
            }

            // 4. case expression => ambil default
            if (Array.isArray(val) && val[0] === "case") {
                const last = val[val.length - 1];
                return typeof last === "string" ? last : null;
            }

            // 5. step / interpolate / zoom-based color → ambil fallback terakhir
            if (Array.isArray(val)) {
                const last = val[val.length - 1];
                if (typeof last === "string") return last;
                if (Array.isArray(last)) return rgbaArrayToCss(last);
            }

            console.warn("Tidak bisa baca warna layer:", layerId, val);
            return null;
        }


        // init map + legend
        window.initMapbox = function() {
            const container = document.getElementById('map');
            if (!container) return;

            // pastikan token & style sudah benar
            mapboxgl.accessToken =
                'pk.eyJ1IjoiZGV2LWNvZGVycyIsImEiOiJja3l4YmM1YnQwZ3VrMndwOGFpcnhobGtpIn0.K-67FDARYgR7zEXLSbR4bg';

            // jika sudah ada instance map lama, optional: destroy dulu
            if (window._mapboxInstance) {
                try {
                    window._mapboxInstance.remove();
                } catch (e) {}
                window._mapboxInstance = null;
            }

            const map = new mapboxgl.Map({
                container: 'map',
                style: 'mapbox://styles/dev-coders/cmhdarx9o002n01s9hv5911ha',
                zoom: 14,
                center: [100.84915003253047, 0.3313522113222831]
            });

            window._mapboxInstance = map;

            map.addControl(new mapboxgl.NavigationControl());

            // nama layer yang ingin ditampilkan di legenda (ganti sesuai nama layer di Mapbox Studio)
            const legendTargets = [{
                    id: 'datakolamikan',
                    label: 'Kolam Ikan'
                },
                {
                    id: 'batasdusun',
                    label: 'Batas Dusun'
                },
                {
                    id: 'batasadministrasidesa',
                    label: 'Batas Desa'
                }
            ];

            // buat container legend jika belum ada
            if (!document.getElementById('legend')) {
                const legendEl = document.createElement('div');
                legendEl.id = 'legend';
                legendEl.className = 'absolute top-4 left-4 bg-white shadow-lg rounded-lg p-4 z-50 text-sm';
                legendEl.innerHTML = '<h3 class="font-semibold mb-2">Legenda</h3><div id="legend-items"></div>';
                document.body.appendChild(legendEl);
            }

            map.on('load', () => {
                const legendContainer = document.getElementById('legend-items');
                legendContainer.innerHTML = '';

                legendTargets.forEach(item => {
                    const color = getLayerColor(map, item.id);

                    // fallback: jika tidak ketemu, coba manual (hardcode) atau skip
                    const displayColor = color || '#cccccc';

                    // buat item legend bergantung jenis layer: jika line -> show line, jika fill -> square
                    // tentukan tipe layer (jika ada)
                    const styleLayer = map.getStyle().layers.find(l => l.id === item.id);
                    const kind = styleLayer ? styleLayer.type : 'fill';
                    const el = document.createElement('div');
                    el.className = 'flex items-center space-x-2 mb-1';
                    console.log(color)

                    if (kind === 'line') {
                        el.innerHTML = `
                        <span style="display:inline-block;width:28px;height:6px;background:${displayColor};border:1px solid #0003"></span>
                        <span>${item.label}</span>
                    `;
                    } else {
                        // default fill / circle
                        el.innerHTML = `
                        <span style="display:inline-block;width:16px;height:16px;background:${displayColor};border:1px solid #0003;border-radius:3px"></span>
                        <span>${item.label}</span>
                    `;
                    }

                    legendContainer.appendChild(el);
                });

                map.on('click', 'datakolamikan', (e) => {
                    const feature = e.features[0];

                    if (!feature || !feature.geometry) {
                        console.warn("Tidak ada geometry pada fitur ini");
                        return;
                    }

                    // POLYGON → coordinates adalah array 3D:
                    // [ [ [lng, lat], [lng, lat], ... ] ]
                    const coords = feature.geometry.coordinates;

                    console.log("=== KOORDINAT POLYGON ===");
                    console.log(JSON.stringify(coords));

                    // Jika mau lebih rapi:
                    coords[0].forEach((point, i) => {
                        console.log(`Point ${i}: ${point[0]}, ${point[1]}`);
                    });
                });

                // Cursor menjadi pointer saat hover
                map.on('mouseenter', 'datakolamikan', () => {
                    map.getCanvas().style.cursor = 'pointer';
                });

                map.on('mouseleave', 'datakolamikan', () => {
                    map.getCanvas().style.cursor = '';
                });
            });

        };

        // jalankan saat load biasa
        document.addEventListener('DOMContentLoaded', () => {
            if (typeof window.initMapbox === 'function') window.initMapbox();
        });

        // jika memakai Livewire Navigasi SPA: panggil init ulang
        document.addEventListener('livewire:navigated', () => {
            if (typeof window.initMapbox === 'function') window.initMapbox();
        });
    </script>
@endpush
