@push('styles')
    <link href="https://api.mapbox.com/mapbox-gl-js/v3.17.0-beta.1/mapbox-gl.css" rel="stylesheet">

    <style>
        /* Map responsive (tanpa absolute) */
        #map {
            width: 100%;
            height: 100vh;
            /* bisa diganti sesuai kebutuhan */
            border-radius: 12px;
            overflow: hidden;
        }

        /* Legend agar tidak keluar layar */
        #legend {
            max-width: 220px;
        }
    </style>
@endpush

<section class="mt-0 px-2 lg:px-2">
    <div class="relative">

        {{-- Legend --}}
        <div id="legend"
            class="absolute top-4 left-4 bg-white shadow-xl rounded-md p-3 z-50 text-sm border border-gray-200">
            <h3 class="font-semibold mb-2 dark:text-slate-900">Legenda</h3>
            <div id="legend-items" class="dark:text-slate-900"></div>
        </div>

        {{-- Map --}}
        <div id="map" wire:ignore></div>
    </div>
    <flux:modal name="create-kolam" class="md:w-96">
        <form wire:submit.prevent="store" class="space-y-6">
            <div>
                <flux:heading size="lg">Update Info Kolam Pemilik</flux:heading>
            </div>
            <flux:field>
                <flux:label>Nama Kolam</flux:label>
                <flux:input wire:model="nama_kolam" placeholder="kolam 1" />
                <flux:error name="nama_kolam" />
            </flux:field>

            <flux:field>
                <flux:label>Jenis Kolam</flux:label>
                <flux:input wire:model="jenis_kolam" placeholder="kolam 1" />
                <flux:error name="jenis_kolam" />
            </flux:field>
            <flux:field>
                <flux:label>Panjang Kolam</flux:label>
                <flux:input wire:model="panjang" placeholder="kolam 1" />
                <flux:error name="panjang" />
            </flux:field>
            <flux:field>
                <flux:label>Lebar_Kolam</flux:label>
                <flux:input wire:model="lebar" placeholder="kolam 1" />
                <flux:error name="lebar" />
            </flux:field>
            <flux:field>
                <flux:label>Kedalaman Kolam</flux:label>
                <flux:input wire:model="kedalaman" placeholder="kolam 1" />
                <flux:error name="kedalaman" />
            </flux:field>
            <flux:field>
                <flux:label>Kapasitas Kolam</flux:label>
                <flux:input wire:model="kapasitas" placeholder="kolam 1" />
                <flux:error name="kapasitas" />
            </flux:field>
            <flux:field>
                <flux:label>Status Kolam</flux:label>
                <flux:radio.group wire:model="status" variant="segmented">
                    <flux:radio value="Aktif" label="Aktif" />
                    <flux:radio value="Rusak" label="Rusak" />
                    <flux:radio value="Sewa" label="Sewa" />
                </flux:radio.group>
                <flux:error name="status" />
            </flux:field>
            <flux:field>
                <flux:label>Pemilik</flux:label>
                <flux:select wire:model="user_id" placeholder="Pilih Pemilik...">
                    <flux:select.option value="" selected>Pilih Pemilik</flux:select.option>
                    @foreach ($dataUser as $list)
                        <flux:select.option value="{{ $list->id }}">{{ $list->name }}</flux:select.option>
                    @endforeach
                </flux:select>
                <flux:error name="user_id" />
            </flux:field>
            <div class="flex">
                <flux:spacer />
                <flux:button type="submit" variant="primary">Save changes</flux:button>
            </div>
        </form>
    </flux:modal>
</section>
@push('scripts')
    <script src="https://api.mapbox.com/mapbox-gl-js/v3.17.0-beta.1/mapbox-gl.js"></script>
    <script>
        const savedPolygons = @json($savedPolygons);
        // util: ubah array rgba -> string css
        function rgbaArrayToCss(arr) {
            // contoh: ['rgba', 255, 0, 0, 0.5] atau ['rgb',255,0,0]
            if (!Array.isArray(arr) || arr.length < 2) return null;
            const t = arr[0];
            if (t === 'rgba' || t === 'rgb') {
                const nums = arr.slice(1).map(n => Number(n));
                if (t === 'rgba') return `rgba(${nums[0]}, ${nums[1]}, ${nums[2]}, ${nums[3]})`;
                return `rgb(${nums[0]}, ${nums[1]}, ${nums[2]})`;
            }
            return null;
        }

        // util: ambil warna dari paint/expr sederhana
        function evaluateColorValue(val) {
            if (!val) return null;

            // string literal: "#ff00aa" atau "rgba(...)" atau "transparent"
            if (typeof val === 'string') return val;

            // array expression: coba beberapa pola
            if (Array.isArray(val)) {
                // rgba / rgb array
                const rgba = rgbaArrayToCss(val);
                if (rgba) return rgba;

                // match expression: ['match', ['get', 'prop'], 'value1', '#f00', 'value2', '#0f0', '#fff']
                if (val[0] === 'match') {
                    // ambil default (akhir) jika ada
                    const last = val[val.length - 1];
                    if (typeof last === 'string') return last;
                }

                // case expression: ['case', cond1, color1, cond2, color2, default]
                if (val[0] === 'case') {
                    const last = val[val.length - 1];
                    if (typeof last === 'string') return last;
                }

                // step/interval/expression lain -> fallback null
                return null;
            }

            return null;
        }

        // util: buat ID random unik
        function generateUniqueId(length = 8) {
            return Math.random().toString(36).substring(2, 2 + length);
        }

        // assign unique id ke semua polygon
        function assignUniqueIds(map, layerId) {
            const layer = map.getLayer(layerId);
            if (!layer) return;

            const features = map.queryRenderedFeatures({
                layers: [layerId]
            });

            features.forEach((feature, index) => {
                if (!feature.properties._unique_id) {
                    const randomId = 'uid_' + Math.random().toString(36).substring(2, 10);
                    feature.properties._unique_id = randomId;

                    // set feature state untuk vector tiles
                    map.setFeatureState({
                        source: 'composite',
                        sourceLayer: 'DataKolamIkan',
                        id: feature.id
                    }, {
                        _unique_id: randomId
                    });
                }
            });

            console.log("Unique ID assigned:");
            console.table(features.map(f => ({
                id: f.id,
                _unique_id: f.properties._unique_id
            })));
        }

        function checkAssignedUniqueIds(map, layerId) {
            // Ambil semua fitur yang dirender dari layer
            const features = map.queryRenderedFeatures({
                layers: [layerId]
            });

            const results = features.map(f => {
                // Ambil feature.id asli
                const featureId = f.id ?? null;

                // Ambil state _unique_id jika ada
                let uniqueId = null;
                if (featureId !== null) {
                    const state = map.getFeatureState({
                        source: 'composite', // sesuaikan source kamu
                        sourceLayer: 'DataKolamIkan', // source-layer di Mapbox Studio
                        id: featureId
                    });
                    uniqueId = state._unique_id || null;
                }

                return {
                    feature_id: featureId,
                    unique_id: uniqueId,
                    name: f.properties.nama || null
                };
            });

            console.table(results);
            return results;
        }
        // UTAMA: dapatkan warna layer
        function getLayerColor(map, layerId) {
            const styleLayer = map.getStyle().layers.find(l => l.id === layerId);
            if (!styleLayer || !styleLayer.paint) return null;

            // kandidat properti
            const keys = [
                'fill-color',
                'line-color',
                'circle-color',
                'background-color',
                'fill-outline-color'
            ];

            let val = null;
            for (const key of keys) {
                if (styleLayer.paint[key] !== undefined) {
                    val = styleLayer.paint[key];
                    break;
                }
            }
            if (!val) return null;

            // 1. Literal warna string
            if (typeof val === "string") return val;

            // 2. rgba/rgb array
            if (Array.isArray(val) && (val[0] === "rgba" || val[0] === "rgb")) {
                return rgbaArrayToCss(val);
            }

            // 3. match expression => ambil default
            if (Array.isArray(val) && val[0] === "match") {
                const last = val[val.length - 1];
                return typeof last === "string" ? last : null;
            }

            // 4. case expression => ambil default
            if (Array.isArray(val) && val[0] === "case") {
                const last = val[val.length - 1];
                return typeof last === "string" ? last : null;
            }

            // 5. step / interpolate / zoom-based color → ambil fallback terakhir
            if (Array.isArray(val)) {
                const last = val[val.length - 1];
                if (typeof last === "string") return last;
                if (Array.isArray(last)) return rgbaArrayToCss(last);
            }

            console.warn("Tidak bisa baca warna layer:", layerId, val);
            return null;
        }


        // init map + legend
        window.initMapbox = function() {
            const container = document.getElementById('map');
            if (!container) return;

            // pastikan token & style sudah benar
            mapboxgl.accessToken =
                'pk.eyJ1IjoiZGV2LWNvZGVycyIsImEiOiJja3l4YmM1YnQwZ3VrMndwOGFpcnhobGtpIn0.K-67FDARYgR7zEXLSbR4bg';

            // jika sudah ada instance map lama, optional: destroy dulu
            if (window._mapboxInstance) {
                try {
                    window._mapboxInstance.remove();
                } catch (e) {}
                window._mapboxInstance = null;
            }

            const map = new mapboxgl.Map({
                container: 'map',
                style: 'mapbox://styles/dev-coders/cmhdarx9o002n01s9hv5911ha',
                zoom: 14,
                center: [100.84915003253047, 0.3313522113222831]
            });

            window._mapboxInstance = map;

            map.addControl(new mapboxgl.NavigationControl());

            // Lebarlayer yang ingin ditampilkan di legenda (ganti sesuai nama layer di Mapbox Studio)
            const legendTargets = [{
                    id: 'datakolamikan',
                    label: 'Kolam Ikan'
                },
                {
                    id: 'batasdusun',
                    label: 'Batas Dusun'
                },
                {
                    id: 'batasadministrasidesa',
                    label: 'Batas Desa'
                }
            ];

            // buat container legend jika belum ada
            if (!document.getElementById('legend')) {
                const legendEl = document.createElement('div');
                legendEl.id = 'legend';
                legendEl.className = 'absolute top-4 left-4 bg-white shadow-lg rounded-lg p-4 z-50 text-sm';
                legendEl.innerHTML = '<h3 class="font-semibold mb-2">Legenda</h3><div id="legend-items"></div>';
                document.body.appendChild(legendEl);
            }

            map.on('load', () => {

                // --- utils ---
                function normalizePolygon(polygon) {
                    if (!Array.isArray(polygon) || polygon.length === 0) return polygon;
                    const ring = polygon[0].slice(); // copy ring pertama
                    const first = ring[0];
                    const last = ring[ring.length - 1];
                    // hapus vertex terakhir jika sama dengan vertex pertama
                    if (first[0] === last[0] && first[1] === last[1]) {
                        ring.pop();
                    }
                    return [ring];
                }

                function isSamePolygon(coordsDB, coordsMap) {
                    const dbRing = normalizePolygon(coordsDB)[0];
                    const mapRing = coordsMap.slice(); // Mapbox polygon ring

                    if (dbRing.length !== mapRing.length) {
                        console.warn("Jumlah titik berbeda:", dbRing.length, mapRing.length);
                        return false;
                    }

                    // buat array perbandingan untuk debug
                    const comparison = dbRing.map((pointDB, i) => {
                        const pointMap = mapRing[i];
                        const lngDiff = Math.abs(pointDB[0] - pointMap[0]);
                        const latDiff = Math.abs(pointDB[1] - pointMap[1]);
                        const same = lngDiff < 0.00001 && latDiff < 0.00001; // toleransi floating point
                        return {
                            index: i,
                            db_lng: pointDB[0],
                            db_lat: pointDB[1],
                            map_lng: pointMap[0],
                            map_lat: pointMap[1],
                            lng_diff: lngDiff,
                            lat_diff: latDiff,
                            same: same
                        };
                    });

                    console.table(comparison);

                    return comparison.every(p => p.same);
                }

                // --- tandai polygon di Mapbox ---
                const features = map.querySourceFeatures('composite', {
                    sourceLayer: 'DataKolamIkan'
                });

                features.forEach((f, index) => {
                    if (!f.id) f.id = index; // beri id sementara jika belum ada
                    const featureCoords = f.geometry.coordinates[0];

                    // cek apakah polygon ini ada di DB
                    const saved = savedPolygons.some(sp => isSamePolygon(sp, featureCoords));

                    console.log('Feature coords:', featureCoords);
                    console.log('Saved in DB?', saved);

                    map.setFeatureState({
                        source: 'composite',
                        sourceLayer: 'DataKolamIkan',
                        id: f.id
                    }, {
                        saved: saved
                    });
                });

                // --- ubah warna layer sesuai feature-state ---
                map.setPaintProperty('datakolamikan', 'fill-color', [
                    'case',
                    ['boolean', ['feature-state', 'saved'], false],
                    '#aaaaaa', // abu-abu jika sudah tersimpan
                    '#3bb2d0' // default
                ]);


                // window.addEventListener('polygon-saved', e => {
                //     const newPoly = e.detail.polygon[0]; // ambil ring pertama
                //     map.querySourceFeatures('datakolamikan').forEach(f => {
                //         const featureCoords = f.geometry.coordinates[0];
                //         if (isSamePolygon(featureCoords, newPoly)) {
                //             map.setFeatureState({
                //                 source: 'datakolamikan',
                //                 id: f.id
                //             }, {
                //                 saved: true
                //             });
                //         }
                //     });
                // });

                const legendContainer = document.getElementById('legend-items');
                legendContainer.innerHTML = '';

                legendTargets.forEach(item => {
                    const color = getLayerColor(map, item.id);

                    // fallback: jika tidak ketemu, coba manual (hardcode) atau skip
                    const displayColor = color || '#cccccc';

                    // buat item legend bergantung jenis layer: jika line -> show line, jika fill -> square
                    // tentukan tipe layer (jika ada)
                    const styleLayer = map.getStyle().layers.find(l => l.id === item.id);
                    const kind = styleLayer ? styleLayer.type : 'fill';
                    const el = document.createElement('div');
                    el.className = 'flex items-center space-x-2 mb-1';
                    console.log(color)

                    if (kind === 'line') {
                        el.innerHTML = `
                        <span style="display:inline-block;width:28px;height:6px;background:${displayColor};border:1px solid #0003"></span>
                        <span>${item.label}</span>
                    `;
                    } else {
                        // default fill / circle
                        el.innerHTML = `
                        <span style="display:inline-block;width:16px;height:16px;background:${displayColor};border:1px solid #0003;border-radius:3px"></span>
                        <span>${item.label}</span>
                    `;
                    }

                    legendContainer.appendChild(el);
                });

                map.on('click', 'datakolamikan', (e) => {
                    const feature = e.features[0];

                    if (!feature || !feature.geometry) {
                        console.warn("Tidak ada geometry pada fitur ini");
                        return;
                    }
                    const coords = feature.geometry.coordinates;
                    const clickPoint = [e.lngLat.lng, e.lngLat.lat];
                    Livewire.find(@this.id).set('polygon', coords); // polygon
                    Livewire.find(@this.id).set('cordinate', clickPoint); // titik klik
                    Livewire.dispatch('openModal');

                    // ambil unique_id dari feature state
                    // ambil feature index dari array fitur yang dirender
                    const features = map.queryRenderedFeatures({
                        layers: ['datakolamikan']
                    });
                    const index = features.findIndex(f => f === feature);

                    // ambil unique_id dari feature state
                    let uniqueId = null;
                    let featureId = feature.id != null ? feature.id : null;

                    if (featureId != null) {
                        const state = map.getFeatureState({
                            source: 'composite',
                            sourceLayer: 'DataKolamIkan',
                            id: featureId
                        });
                        uniqueId = state._unique_id || null;
                    }
                    console.log(
                        `Clicked feature index: ${index}, id: ${featureId}, unique_id: ${uniqueId}`);
                });

                // Cursor menjadi pointer saat hover
                map.on('mouseenter', 'datakolamikan', () => {
                    map.getCanvas().style.cursor = 'pointer';
                });

                map.on('mouseleave', 'datakolamikan', () => {
                    map.getCanvas().style.cursor = '';
                });
            });

        };

        // jalankan saat load biasa
        document.addEventListener('DOMContentLoaded', () => {
            if (typeof window.initMapbox === 'function') window.initMapbox();
        });

        // jika memakai Livewire Navigasi SPA: panggil init ulang
        document.addEventListener('livewire:navigated', () => {
            if (typeof window.initMapbox === 'function') window.initMapbox();
        });
    </script>
@endpush
