<?php

namespace App\Livewire\Admin\Datakolam;

use Livewire\Component;
use Masmerise\Toaster\Toaster;
use App\Models\DataKolam;
use Livewire\Attributes\On;
use App\Models\User;
class Create extends Component
{
    public $nama_kolam, $jenis_kolam, $panjang, $lebar, $kedalaman, $status, $user_id, $kapasitas;
    public $polygon = [];
    public $cordinate = [];
    public $showModal = false;
    public $selectedKolam = null;

    public $dataUser = [];

    public $savedPolygons = [];
    protected $listeners = [
        'polygonClicked' => 'openModalFromMap'
    ];
    public function mount()
    {
        $this->dataUser = User::where('role', 'Pemilik Kolam')->get();
        $this->loadSavedPolygons();
        // dd($this->savedPolygons);
    }

    public function loadSavedPolygons()
    {
        $this->savedPolygons = DataKolam::pluck('polygon')
            ->map(function ($poly) {
                return $poly ? json_decode($poly, true) : null;
            })
            ->filter() // buang null
            ->values()
            ->toArray();
    }
    public function store()
    {
        $validate = $this->validate([
            'nama_kolam' => 'required',
            'jenis_kolam' => 'required',
            'panjang' => 'required',
            'lebar' => 'required',
            'kedalaman' => 'required',
            'kapasitas' => 'required',
            'status' => 'required',
            'user_id' => 'required',
        ]);
        $kolam = new DataKolam();
        $kolam->nama_kolam = $this->nama_kolam;
        $kolam->jenis_kolam = $this->jenis_kolam;
        $kolam->panjang = $this->panjang;
        $kolam->lebar = $this->lebar;
        $kolam->kedalaman = $this->kedalaman;
        $kolam->kapasitas = $this->kapasitas;
        $kolam->user_id = $this->user_id;
        $kolam->status = $this->status;
        $kolam->polygon = json_encode($this->polygon);
        $kolam->cordinate = json_encode($this->cordinate);
        $kolam->save();
        Toaster::success('Kolam created!');
        $this->reset();

    }

    #[On('openModal')]
    public function openModal()
    {
        $this->modal('create-kolam')->show();
    }

    public function openModalFromMap($kolamId)
    {
        $this->selectedKolam = DataKolam::find($kolamId);
        $this->showModal = true;

        // Trigger event ke JS untuk resize map
        $this->dispatch('force-map-resize');
    }
    public function render()
    {
        return view('livewire.admin.datakolam.create');
    }
}
