<?php

namespace App\Livewire\Admin\Datakolam;

use Livewire\Component;

class Update extends Component
{
    public function render()
    {
        return view('livewire.admin.datakolam.update');
    }
}
